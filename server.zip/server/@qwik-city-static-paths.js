const staticPaths = new Set(["/404.html/","/404.webp","/adanor.svg","/contact/contact.jpg","/favicon.ico","/foods/002-200.webp","/foods/002-400.webp","/foods/002-800.webp","/foods/003-200.webp","/foods/003-400.webp","/foods/003-800.webp","/foods/004-200.webp","/foods/004-400.webp","/foods/004-800.webp","/foods/105-200.webp","/foods/105-400.webp","/foods/105-800.webp","/foods/107-200.webp","/foods/107-400.webp","/foods/107-800.webp","/foods/110-200.webp","/foods/110-400.webp","/foods/110-800.webp","/foods/212-200.webp","/foods/212-400.webp","/foods/212-800.webp","/foods/305-200.webp","/foods/305-400.webp","/foods/305-800.webp","/foods/306-200.webp","/foods/306-400.webp","/foods/306-800.webp","/foods/315-200.webp","/foods/315-400.webp","/foods/315-800.webp","/foods/316-200.webp","/foods/316-400.webp","/foods/316-800.webp","/foods/320-200.webp","/foods/320-400.webp","/foods/320-800.webp","/foods/330-200.webp","/foods/330-400.webp","/foods/330-800.webp","/foods/402-200.webp","/foods/402-400.webp","/foods/402-800.webp","/foods/404-200.webp","/foods/404-400.webp","/foods/404-800.webp","/foods/407-200.webp","/foods/407-400.webp","/foods/407-800.webp","/foods/410-200.webp","/foods/410-400.webp","/foods/410-800.webp","/foods/411-200.webp","/foods/411-400.webp","/foods/411-800.webp","/foods/413-200.webp","/foods/413-400.webp","/foods/413-800.webp","/foods/415-200.webp","/foods/415-400.webp","/foods/415-800.webp","/foods/423-200.webp","/foods/423-400.webp","/foods/423-800.webp","/foods/512-200.webp","/foods/512-400.webp","/foods/512-800.webp","/foods/522-200.webp","/foods/522-400.webp","/foods/522-800.webp","/foods/529-200.webp","/foods/529-400.webp","/foods/529-800.webp","/foods/530-200.webp","/foods/530-400.webp","/foods/530-800.webp","/foods/532-200.webp","/foods/532-400.webp","/foods/532-800.webp","/foods/533-200.webp","/foods/533-400.webp","/foods/533-800.webp","/foods/534-200.webp","/foods/534-400.webp","/foods/534-800.webp","/foods/536-200.webp","/foods/536-400.webp","/foods/536-800.webp","/foods/537-200.webp","/foods/537-400.webp","/foods/537-800.webp","/foods/540-200.webp","/foods/540-400.webp","/foods/540-800.webp","/foods/702-200.webp","/foods/702-400.webp","/foods/702-800.webp","/foods/706-200.webp","/foods/706-400.webp","/foods/706-800.webp","/foods/707-200.webp","/foods/707-400.webp","/foods/707-800.webp","/foods/708-200.webp","/foods/708-400.webp","/foods/708-800.webp","/hero/about-1000.webp","/hero/about-1200.webp","/hero/about-1500.webp","/hero/about-200.webp","/hero/about-400.webp","/hero/about-800.webp","/hero/contact-1000.webp","/hero/contact-1200.webp","/hero/contact-1500.webp","/hero/contact-200.webp","/hero/contact-400.webp","/hero/contact-800.webp","/hero/food-1000.webp","/hero/food-1200.webp","/hero/food-1500.webp","/hero/food-200.webp","/hero/food-400.webp","/hero/food-800.webp","/hero/group-1000.webp","/hero/group-1200.webp","/hero/group-1500.webp","/hero/group-200.webp","/hero/group-400.webp","/hero/group-800.webp","/hero_video/group.mp4","/home/hero.mp4","/home/hero.webp","/manifest.json","/pdf/group_2025_en.doc","/pdf/group_2025_en.pdf","/pdf/group_2025_hu.doc","/pdf/group_2025_hu.pdf","/profile_pic.webp","/promo_video/promo_1.mp4","/q-manifest.json","/qwik-prefetch-service-worker.js","/robots.txt","/service-worker.js","/sitemap.xml","/szechenyi.png"]);
function isStaticPath(method, url) {
  if (method.toUpperCase() !== 'GET') {
    return false;
  }
  const p = url.pathname;
  if (p.startsWith("/build/")) {
    return true;
  }
  if (p.startsWith("/assets/")) {
    return true;
  }
  if (staticPaths.has(p)) {
    return true;
  }
  if (p.endsWith('/q-data.json')) {
    const pWithoutQdata = p.replace(/\/q-data.json$/, '');
    if (staticPaths.has(pWithoutQdata + '/')) {
      return true;
    }
    if (staticPaths.has(pWithoutQdata)) {
      return true;
    }
  }
  return false;
}
export { isStaticPath };